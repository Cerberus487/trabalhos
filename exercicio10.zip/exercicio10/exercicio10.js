window.addEventListener("load",function(){
    document.getElementById("btn").addEventListener("click",function(){
        var num = parseInt(document.getElementById("txtn").value);
        var resp = document.getElementById("txtf");
        var fat = 1;
        for (var i=1; i<=num; i++){
            fat *= i;
        } 
        resp.value = fat;
    });
});