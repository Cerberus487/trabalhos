var secret;
function sortearN(){
    secret = Math.round(Math.random()*100);
}

window.addEventListener("load",function(){
    sortearN();
    var tentativas=0;
    document.getElementById("btn").addEventListener("click",function(){
        var n = parseInt(document.getElementById("txtnum").value);
        var resp = document.getElementById("saida");
        tentativas++;
        if (n < secret){
            resp.innerHTML="O número deve ser maior <br>. Tentativas = "+tentativas;
        }else if (n > secret){
            resp.innerHTML="O número deve ser menor <br>. Tentativas = "+tentativas;
        }else{
            resp.innerHTML="Você acertou...Parabéns!<br> Tentativas = "+tentativas;
        }
    });
});