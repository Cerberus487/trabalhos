function calcIMC(peso, altura){
    return peso / (altura * altura);
}
function exibeMSG(imc, genero){
    var respmsg = document.getElementById("resp_msg");
    if (genero == 'f'){
        if (imc <= 19.1){
            respmsg.value="abaixo do peso";
        }else if (imc <=25.8){
            respmsg.value="peso normal";
        }else if (imc <=27.3){
            respmsg.value="acima do peso";
        }else if (imc <=32.3){
            respmsg.value="acima do peso ideal"
        }else{
            respmsg.value="Obeso";
        }
    }else{
        
            if (imc <= 20.7){
                respmsg.value="abaixo do peso";
            }else if (imc <=26.4){
                respmsg.value="peso normal";
            }else if (imc <=27.8){
                respmsg.value="acima do peso";
            }else if (imc <=31.1){
                respmsg.value="acima do peso ideal"
            }else{
                respmsg.value="Obeso";
            }
    }
}

window.addEventListener("load",function(){
    document.getElementById("btn").addEventListener("click", function(){
        var a = parseFloat(document.getElementById("txtaltura").value);
        var p = parseFloat(document.getElementById("txtpeso").value);
        var g = document.getElementById("genero").value;
        var imc = calcIMC(p, a);
        document.getElementById("resp_imc").value = imc.toFixed(2);
        exibeMSG(imc, g); 
    });
});
