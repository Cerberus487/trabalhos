window.addEventListener("load", function(){
    document.getElementById("btn").addEventListener("click",function(){
        var v1 = parseInt(document.getElementById("txtv1").value);
        var v2 = parseInt(document.getElementById("txtv2").value);
        var resp = document.getElementById("resp");
        if (v1 > v2){
            resp.value = "Maior: "+ v1;
        }else if (v2 > v1){
            resp.value = "Maior: "+ v2;
        }else{
            resp.value = "São Iguais";
        }
    });
});