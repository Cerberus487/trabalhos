window.addEventListener("load", function(){
    document.getElementById("btn").addEventListener("click",function(){
        var num = parseInt(document.getElementById("txtvalor").value);
        if (num%2 == 0){
            resp.value = "É par";
        }else{
            resp.value = "É ímpar";
        }
    });
});
