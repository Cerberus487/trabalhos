window.onload = function(){
    document.getElementById("botao").onclick = function(){
        calcular();
    }
}

function calcular(){
    var elementos_valor = document.getElementById("txtvalor");
    var elementos_parcela = document.getElementById("txtparcelas");
    var elementos_resposta = document.getElementById("txtresult");

    var valorcompra= parseFloat(elementos_valor.value);
    var quantidadeparcelas= parseInt(elementos_parcela.value);

    var msg="";
    var valorfinal = 0;

    if(quantidadeparcelas == 1){
        valorfinal = valorcompra;
        msg = "1x" + valorfinal;
    }else if(quantidadeparcelas == 2){
        valorfinal = (valorcompra + (valorcompra * 0.03))/2;
        msg = "2x" + valorfinal;
    }else{
        valorfinal = (valorcompra + (valorcompra * 0.07))/4;
        msg = "4x" + valorfinal;
    }

    elementos_valor.value ="";
    elementos_resposta.value = msg;
}